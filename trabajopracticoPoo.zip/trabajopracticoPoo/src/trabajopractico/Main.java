package trabajopractico;

public class Main {
    public static void main(String[] args) {
        CuentaBancaria yo = new CuentaBancaria("martin", "40900832");

        yo.mostrarMenu();

    }
}
